# SnipChat — Capacitor + GitHub Actions Setup

## Prerequisites

- Node.js 20+
- Android Studio (for Android)
- Xcode 15+ on macOS (for iOS)
- Apple Developer account (for signed iOS builds)

---

## 1. First-time local setup

```bash
npm install

# Add native platforms (only needed once)
npm run cap:add:android
npm run cap:add:ios

# Build web app and sync to native projects
npm run build && npm run cap:sync
```

---

## 2. Run on device / emulator

```bash
# Android — opens in Android Studio
npm run cap:open:android

# iOS — opens in Xcode (macOS only)
npm run cap:open:ios
```

---

## 3. GitHub Actions — what runs automatically

| Trigger | Android | iOS |
|---|---|---|
| Push to `main` | ✅ Debug APK | ✅ Simulator build (unsigned) |
| Tag `v*` (e.g. `v1.0.0`) | ✅ Signed release APK | ✅ Signed IPA |

Artifacts are downloadable from the **Actions** tab in your GitHub repo.

---

## 4. Secrets you must add in GitHub

Go to **Settings → Secrets and variables → Actions** and add:

### Android (release APK)

| Secret | How to get it |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | `base64 -i your-key.keystore` |
| `KEYSTORE_PASSWORD` | Password you set when generating the keystore |
| `KEY_ALIAS` | Alias you set when generating the keystore |
| `KEY_PASSWORD` | Key password (often same as keystore password) |

Generate a keystore (one-time):
```bash
keytool -genkey -v -keystore snipchat.keystore \
  -alias snipchat -keyalg RSA -keysize 2048 -validity 10000
```

### iOS (signed IPA)

| Secret | How to get it |
|---|---|
| `IOS_CERTIFICATE_BASE64` | Export `.p12` from Keychain, then `base64 -i cert.p12` |
| `IOS_CERTIFICATE_PASSWORD` | Password set when exporting `.p12` |
| `IOS_PROVISIONING_PROFILE_BASE64` | Download from developer.apple.com, then `base64 -i profile.mobileprovision` |
| `KEYCHAIN_PASSWORD` | Any strong random string — used only in CI |

---

## 5. Update `ios/ExportOptions.plist`

Replace `YOUR_TEAM_ID` with your Apple Developer Team ID (found at developer.apple.com/account).

Change `method` to `app-store` when you're ready to submit to the App Store.

---

## 6. Camera permissions

### Android
In `android/app/src/main/AndroidManifest.xml`, these are added automatically by `@capacitor/camera`:
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

### iOS
In `ios/App/App/Info.plist`, add:
```xml
<key>NSCameraUsageDescription</key>
<string>SnipChat needs camera access to take snaps.</string>
<key>NSPhotoLibraryAddUsageDescription</key>
<string>SnipChat saves your snaps to your photo library.</string>
```

---

## 7. Tag a release

```bash
git tag v1.0.0
git push origin v1.0.0
```

This triggers the signed APK + IPA builds automatically.
